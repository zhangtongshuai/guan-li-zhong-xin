require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager','jiathis'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//获取资讯id
    	var news_id = GetQueryString('news_id');
		//获取消息
    	$.ajax({
    		type: "get",
    		url: api+"/api/news?access_token="+access_token+"&user_id="+user_id+"&news_id="+news_id,
    		async: true,
    		dataType: 'json'
    	}).then(function(msgdetail){
    		//console.log(msgdetail);
    		if(msgdetail.err_code != 0){
    			layer.alert(msgdetail.msg, {'title': false,'closeBtn': 0});
    			return false;
    		}
    		$('.buyer-right-bottom h3').html(msgdetail.data.title);
    		$('.msgzhu span:eq(0)').html(msgdetail.data.pub_user);
    		$('.msgzhu span:eq(1)').html(msgdetail.data.pub_time);
    		
    		if(msgdetail.data.news_type == 0){
    			$('.msgtop .newstype').html('头条');
    		}else if(msgdetail.data.news_type == 1){
    			$('.msgtop .newstype').html('平台资讯');
    		}else if(msgdetail.data.news_type == 2){
    			$('.msgtop .newstype').html('行业动态');
    		}else{
    			$('.msgtop .newstype').html('产业链');
    		}
    		
    		$('.msgcontent').html(msgdetail.data.content);
    	});
    	/**
    	 * 交互效果
    	 */
    	
    	//从浏览器的地址栏获取传参
		function GetQueryString(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(3).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});