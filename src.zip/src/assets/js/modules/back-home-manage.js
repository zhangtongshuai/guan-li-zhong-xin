require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
    	// access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
    	// user_id = 100000;
    	/**
    	 * 交互效果
    	 */
		//上传顶部广告图片
        $('.product-zhan-up').on('change', function(event) {
            //获取图片的大小
            var fileSize = this.files[0].size;
            //对于图片的大小进行比较
            if(fileSize > 2 * 1024 * 1024) {
                layer.alert("上传图片大小不能超过2M");
                return false;
            } else {
                var file = $(this)[0].files[0];
                if(!/image\/\w+/.test(file.type)){
                    layer.alert("请确保文件为图像类型");
                    return false;
                }
                r = new FileReader();  //本地预览
                r.onload = function() {
                    var pictureFile = r.result;
                    var product_commit_obj = {
                        user_id: user_id,
                        access_token: access_token,
                        simage: pictureFile
                    };
                    //console.log(product_commit_obj);
                    $.ajax({
                        type: "post",
                        url: api + "/api/upload_image",
                        async: true,
                        data: JSON.stringify(product_commit_obj),
                        dataType: 'json'
                    }).then(function (r) {
                        //console.log(r);
                        if(r.err_code == 0){
                            $(".banner_img").attr('src', r.data.image_url)
                            $("#banner_preview_img img").attr('src', r.data.image_url);
                            $("#banner_preview_img").css({"display": "block"})
                            $(".keepbtn").css({"display": "block"})
                            //保存顶部广告
                            $(".hold_btn").click(function () {

                                //顶部广告图片
                                var piccArr = $(this).parents(".buyer-right-bottom").find('.banner_img').attr('src');
                                var insertData = {
                                    'image_url': piccArr
                                };
                                //console.log(JSON.stringify(insertData));
                                //发送数据到后台
                                $.ajax({
                                    type: "POST",
                                    async: true,
                                    data: JSON.stringify(insertData),
                                    dataType: "json",
                                    url: api + '/api/ad?access_token=' + access_token + '&user_id=' + user_id,
                                    contentType: "application/json; charset=utf-8",
                                    success: function (re) {
                                        //console.log(r);
                                        if (re.err_code == 0) {
                                            layer.alert('图片上传成功');
                                            $(".photo_upload").css({"display": "block"})
                                            $('.keepbtn').css({"display": "none"})
                                        } else {
                                            layer.alert(re.msg);
                                        }
                                    },
                                    error: function () {
                                        layer.alert('发生错误，请求数据失败！');
                                    }
                                });
                            });
                        }else{
                            layer.alert(r.msg)
                        }

                    });
                }
                r.readAsDataURL(file);    //Base64
            }
        });

        // //上传图片的方法
        // function convertImgToBase64(url, callback, outputFormat) {
        //     var canvas = document.createElement('CANVAS');
        //     var ctx = canvas.getContext('2d');
        //     var img = new Image;
        //     img.crossOrigin = 'Anonymous';
        //     img.onload = function() {
        //         var width = img.width;
        //         var height = img.height;
        //         // 按比例压缩4倍
        //         var rate = (width < height ? width / height : height / width) / 1;
        //         canvas.width = width * rate;
        //         canvas.height = height * rate;
        //         ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
        //         var dataURL = canvas.toDataURL(outputFormat || 'image/png');
        //         callback.call(this, dataURL);
        //         canvas = null;
        //     };
        //     img.src = url;
        // }
        // function getObjectURL(file) {
        //     var url = null;
        //     if(window.createObjectURL != undefined) { // basic
        //         url = window.createObjectURL(file);
        //     } else if(window.URL != undefined) { // mozilla(firefox)
        //         url = window.URL.createObjectURL(file);
        //     } else if(window.webkitURL != undefined) { // web_kit or chrome
        //         url = window.webkitURL.createObjectURL(file);
        //     }
        //     return url;
        // }

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});