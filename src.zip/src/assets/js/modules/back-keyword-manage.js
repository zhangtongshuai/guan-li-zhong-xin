require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
    	// access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
    	// user_id = 100000;

    	/**
    	 * 交互效果
    	 */
        $.ajax({
            type: 'get',
            url: api + '/api/keyword?access_token='+access_token+'&user_id='+user_id,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success:function(r) {
                //console.log(r);
                if (r.data != null) {
                    var data = r.data;
                    var html = template('tpl-keyword-list-info', data);
                    document.getElementById('keyword-list-info').innerHTML = html;

                    $(".icon-garbagecan").click(function () {
                        var delBtn = $(this);
                        var keyword_id = $(this).parents("tr").find("td:nth-of-type(1)").html();
                        layer.open({
                            content: '您是否确定删除？'
                            ,btn: ['是', '否']
                            ,yes: function(offerData){
                                $.ajax({
                                    type: 'delete',
                                    url : api + '/api/keyword?access_token='+access_token+'&user_id='+user_id+'&id='+keyword_id,
                                    dataType: 'json',
                                    contentType: "application/json; charset=utf-8",
                                    success:function(r){
                                        //console.log(finishData);
                                        if(r.err_code ==0){
                                            layer.alert('删除成功', {icon: 1});
                                            //window.location.reload();
                                            delBtn.parents('tr').remove();
                                        }else{
                                            layer.alert(r.msg);
                                        }

                                    }
                                });
                            },btn2: function(){
                                //按钮【按钮二】的回调
                            }
                            ,cancel: function(){
                                //右上角关闭回调
                            }
                        });
                    })
                }
            }
        });
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
    });
});