var user_type = Cookies.get('user_type');
if(typeof user_type == 'undefined' || user_type == '0' || user_type == '1'){
	window.location.href = 'http://pt.bancai.com/login.html';
}
