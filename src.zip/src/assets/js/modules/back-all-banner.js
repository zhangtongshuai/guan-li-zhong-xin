require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
    	// access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
    	// user_id = 100000;

    	/**
    	 * 交互效果
    	 */
        //分页数量
        function getParameter(name) {
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if (r!=null) return unescape(r[2]); return null;
        }
        function searchFilter(pageindex){
            var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
            }
            //获取全部banner
            //console.log(api + '/api/banner?access_token='+access_token+'&user_id='+user_id+'&page_no='+pageNo)
            $.ajax({
                type: 'get',
                url: api + '/api/banner?access_token='+access_token+'&user_id='+user_id+'&page_no='+pageNo,
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                success:function(r){
                    //console.log(r);
                        var count = parseInt(r.data.record_total);
                        var totalPage = parseInt(r.data.page_total);
                        //遮罩部分
                        $(function(){
                            $(".bg").click(function(){
                                $(".bg").fadeOut(800);
                                $('.view_banner').fadeOut(800);
                            });
                            $(".view_banner_img").click(function(){
                                $(this).parents(".banner_info_img").find(".bg").fadeIn(200);
                                $(this).parents(".banner_info_img").find(".view_banner").fadeIn(400);
                            });
                        });
                    if (count == 0) {
                        $('#no-data').show();
                        $('#kkpager').hide();
                    }else{

                        $('#no-data').hide();
                        $('#kkpager').show();
                        var data=r.data.list;
                        var html=template('tpl-banner-list-info',data);
                        document.getElementById('banner-list-info').innerHTML=html;
                        //生成分页
                        kkpager.generPageHtml({
                            pno: pageNo,
                            //总页码
                            total : totalPage,
                            //总数据条数
                            totalRecords : count,
                            mode : 'click',
                            click : function(n){
                                this.selectPage(pageNo);
                                searchPage(n);
                                return false;
                            }
                        },true);

                        $(".icon-garbagecan").click(function () {
                            var deletBtn = $(this);
                            var banner_id = $(this).parents("tr").find("td:nth-of-type(1)").html();
                            layer.open({
                                content: '您是否确定删除？'
                                ,btn: ['是', '否']
                                ,yes: function(offerData){
                                    $.ajax({
                                        type: 'delete',
                                        url : api + '/api/banner?access_token='+access_token+'&user_id='+user_id+'&banner_id='+banner_id,
                                        dataType: 'json',
                                        contentType: "application/json; charset=utf-8",
                                        success:function(r){
                                            //console.log(finishData);
                                            if(r.err_code ==0){
                                                layer.alert('删除成功', {icon: 1});
                                                //window.location.reload();
                                                deletBtn.parents('tr').remove()
                                            }else{
                                                layer.alert(r.msg);
                                            }

                                        }
                                    });
                                },btn2: function(){
                                    //按钮【按钮二】的回调
                                }
                                ,cancel: function(){
                                    //右上角关闭回调
                                }
                            });
                        });
                    }
                }
            });
        }
        //init
        $(function () {
            searchFilter(1)
        });
        //ajax翻页
        function searchPage(n) {
            searchFilter(n);
        }
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(3)").find("a").css({"color": "#ff3c00"});
    });
});