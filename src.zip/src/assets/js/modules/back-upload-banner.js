require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
    	// access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
    	// user_id = 100000;

    	/**
    	 * 交互效果
    	 */
    	//选择开始日期和结束日期
        ;!function(){
            var laydate = layui.laydate;
            laydate.render({
                elem: '#begin_date' //指定元素
            });
            laydate.render({
                elem: '#end_date' //指定元素
            });
        }();
            //上传banner
        var pictureFile; //图片base64信息
        $('.product-zhan-up').on('change', function(event) {
            //获取图片的大小
            var fileSize = this.files[0].size;
            //对于图片的大小进行比较
            if(fileSize > 1 * 1024 * 1024) {
                layui.alert("上传图片大小不能超过1M");
                return false;
            } else {
                var imageUrl = getObjectURL($(this)[0].files[0]);
                convertImgToBase64(imageUrl, function(base64Img) {
                    pictureFile = base64Img;
                    var product_commit_obj = {
                        user_id: user_id,
                        access_token: access_token,
                        simage: pictureFile
                    };
                    //console.log(product_commit_obj);
                    $.ajax({
                        type: "post",
                        url: api+"/api/upload_image",
                        async:true,
                        data: JSON.stringify(product_commit_obj),
                        dataType: 'json'
                    }).then(function(r){
                        //console.log(r)
                        if(r.err_code ==0){
                            $("#banner_showimg").attr('src',r.data.image_url)
                            $(".upload-banner-info .banner-info:nth-of-type(3)").css({"display":"block"})
                        }else{
                            layer.alert(r.msg);
                        }
                    });
                });
                event.preventDefault();
            }
        });

        //上传图片的方法
        function convertImgToBase64(url, callback, outputFormat) {
            var canvas = document.createElement('CANVAS');
            var ctx = canvas.getContext('2d');
            var img = new Image;
            img.crossOrigin = 'Anonymous';
            img.onload = function() {
                var width = img.width;
                var height = img.height;
                // 按比例压缩4倍
                var rate = (width < height ? width / height : height / width) /0.5;
                canvas.width = width * rate;
                canvas.height = height * rate;
                ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
                var dataURL = canvas.toDataURL(outputFormat || 'image/png');
                callback.call(this, dataURL);
                canvas = null;
            };
            img.src = url;
        }
        function getObjectURL(file) {
            var url = null;
            if(window.createObjectURL != undefined) { // basic
                url = window.createObjectURL(file);
            } else if(window.URL != undefined) { // mozilla(firefox)
                url = window.URL.createObjectURL(file);
            } else if(window.webkitURL != undefined) { // web_kit or chrome
                url = window.webkitURL.createObjectURL(file);
            }
            return url;
        }

        //提交banner
        $(".hold_btn").click(function(){

            var beginTime = $("#begin_date").val();
            var endTime = $("#end_date").val();
            var beginTime1 = new Date(beginTime).getTime();
            var endTime1 = new Date(endTime).getTime();
            if(endTime1<=beginTime1){
                layer.alert('结束时间必须大于开始时间');
                return false;
            }
            if ($("#text_info").val() == '') {
                layer.alert('标题没有填');
                return false;
            } else if ($("#banner_showimg").attr("src") == '') {
                layer.alert("banner图片未上传");
                return false;
            } else if ($("#begin_date").val() == '') {
                layer.alert("开始时间不能为空");
                return false;
            } else if ($("#end_date").val() == '') {
                layer.alert("结束时间不能为空");
                return false;
            }

            var piccArr = $(this).parents(".buyer-right-bottom").find('#banner_showimg').attr('src');
            var insertData = {
                'image_url': piccArr,
                'title':$("#text_info").val(),
                'begin_date':$("#begin_date").val(),
                'end_date':$("#end_date").val()
            };
            //console.log(JSON.stringify(insertData));
            //console.log(api+'/api/banner?access_token='+ access_token +'&user_id='+ user_id);
            //发送数据到后台
            $.ajax({
                type:"POST",
                async:true,
                data: JSON.stringify(insertData),
                dataType: "json",
                url:api+'/api/banner?access_token='+ access_token +'&user_id='+ user_id,
                contentType: "application/json; charset=utf-8",
                success : function(r){
                    //console.log(msg);
                    if(r.err_code ==0){
                        layer.alert('banner上传成功');
                        $("#point_out_info").css({"display":"block"})
                    }else{
                        layer.alert(r.msg);
                    }
                },
                error:function(){
                    layer.alert('发生错误，请求数据失败！');
                }
            });
        });

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});