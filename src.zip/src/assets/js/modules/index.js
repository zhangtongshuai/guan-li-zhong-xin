require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
		$.ajax({
			type: "get",
			url: api+"/api/index?access_token="+access_token+"&user_id="+user_id,
			async: true,
			dataType: 'json'
		}).then(function(indexmsg){
			//console.log(indexmsg);
			if(indexmsg.err_code == 0){
				$('.index-box p:eq(0) span:eq(0) strong b:eq(0)').text(indexmsg.data.ent_count);
				$('.index-box p:eq(0) span:eq(1) strong b:eq(0)').text(indexmsg.data.per_count);
				$('.index-box p:eq(0) span:eq(2) strong b:eq(0)').text(indexmsg.data.product_count);
				
				$('.index-box p:eq(1) span:eq(0) strong b:eq(0)').text(indexmsg.data.new_seller);
				$('.index-box p:eq(1) span:eq(1) strong b:eq(0)').text(indexmsg.data.new_buyer);
				
				$('.index-box p:eq(2) span:eq(0) strong b:eq(0)').text(indexmsg.data.pur_count);
				$('.index-box p:eq(2) span:eq(1) strong b:eq(0)').text(indexmsg.data.order_count);
			}else{
				layer.alert(indexmsg.msg, {'title': false,'closeBtn': 0});
			}
		});
    	/**
    	 * 交互效果
    	 */
		$('.index-box p:eq(0) span:eq(0)').on('click', function(){
			window.location.href = 'back-ent.html';
		});
		$('.index-box p:eq(0) span:eq(1)').on('click', function(){
			window.location.href = 'back-per.html';
		});
		$('.index-box p:eq(0) span:eq(2)').on('click', function(){
			window.location.href = 'back-product.html';
		});
    });
});