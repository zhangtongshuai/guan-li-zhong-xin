require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//获取消息id
    	var id = GetQueryString('id');
    	
    	$.ajax({
    		type: "get",
    		url: api+"/api/per_cert?access_token="+access_token+"&user_id="+user_id+"&id="+id,
    		async:true,
    		dataType: 'json'
    	}).then(function(perdetail){
    		//console.log(perdetail);
    		if(perdetail.err_code == 0){    			
    			var html = template('ent-detail-tem', perdetail.data);
    			$('#ent-detail').html(html);
    			$('#per-pic img').attr({'src': perdetail.data.id_card_img});
    		}else{
    			layer.alert(perdetail.msg, {'title': false,'closeBtn': 0});
    		}
    	});
	    
    	/**
    	 * 交互效果
    	 */
    	//点击通过驳回按钮
    	$('.ent-detail-bottom span:eq(0)').on('click', function(){
    		var content = {
    			'id': id,
    			'type': 1,
    			'audit_msg': $('.ent-detail-center textarea').val()
    		};
    		
    		$.ajax({
    			type: "post",
    			url: api+"/api/per_cert?access_token="+access_token+"&user_id="+user_id,
    			async: true,
    			data: JSON.stringify(content),
    			dataType: 'json'
    		}).then(function(certmsg){
    			if(certmsg.err_code == 0){
    				layer.alert('通过成功', {'title': false,'closeBtn': 0}, function(){
    					window.location.href = 'back-per.html';
    				});
    			}else{
    				layer.alert(certmsg.msg, {'title': false,'closeBtn': 0});
    			}
    		});
    	});
    	$('.ent-detail-bottom span:eq(1)').on('click', function(){
    		var content = {
    			'id': id,
    			'type': 2,
    			'audit_msg': $('.ent-detail-center textarea').val()
    		};
    		
    		$.ajax({
    			type: "post",
    			url: api+"/api/ent_cert?access_token="+access_token+"&user_id="+user_id,
    			async: true,
    			data: JSON.stringify(content),
    			dataType: 'json'
    		}).then(function(certmsg){
    			if(certmsg.err_code == 0){
    				layer.alert('驳回成功', {'title': false,'closeBtn': 0}, function(){
    					window.location.href = 'back-per.html';
    				});
    			}else{
    				layer.alert(certmsg.msg, {'title': false,'closeBtn': 0});
    			}
    		});
    	});
    	
    	//点击ent_pic元素隐藏
    	$('#per-pic').on('click', function(){
    		$(this).hide();
    	});
    	//点击图片显示大图
    	$('#ent-detail').on('click', 'img', function(){
    		$('#per-pic').show();
    	});
    	
    	//从浏览器的地址栏获取传参
		function GetQueryString(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});