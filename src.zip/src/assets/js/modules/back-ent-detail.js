require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//获取企业的id号
    	var id = GetQueryString('id');
    	//获取企业信息
    	$.ajax({
    		type: "get",
    		url: api+"/api/ent_cert?access_token="+access_token+"&user_id="+user_id+"&id="+id,
    		async:true,
    		dataType: 'json'
    	}).then(function(entdetail){
    		//console.log(entdetail);
    		if(entdetail.err_code == 0){    			
    			var html = template('ent-detail-tem1', entdetail.data);
    			$('#ent-detail .ent-detail-top').html(html);
    			var html2 = template('ent-detail-tem2', entdetail.data.cert_info);
    			$('#ent-detail .ent-detail-center li').eq(0).html(html2);
    			var html3 = template('ent-detail-tem3', entdetail.data.ent_info);
    			$('#ent-detail .ent-detail-center li').eq(1).html(html3);
    			
    			$('#ent-pic img').attr({'src': entdetail.data.cert_info.cert_img});
    		}else{
    			layer.alert(entdetail.msg, {'title': false, 'closeBtn': 0});
    		}
    	});
	    
    	/**
    	 * 交互效果
    	 */
    	//点击通过驳回按钮
    	$('.ent-detail-bottom span:eq(0)').on('click', function(){
    		var content = {
    			'id': id,
    			'type': 1,
    			'audit_msg': ''
    		};
    		
    		$.ajax({
    			type: "post",
    			url: api+"/api/ent_cert?access_token="+access_token+"&user_id="+user_id,
    			async: true,
    			data: JSON.stringify(content),
    			dataType: 'json'
    		}).then(function(certmsg){
    			if(certmsg.err_code == 0){
    				layer.alert('通过成功', {'title': false,'closeBtn': 0}, function(){
    					window.location.href = 'back-ent.html';
    				});
    			}else{
    				layer.alert(certmsg.msg, {'title': false,'closeBtn': 0});
    			}
    		});
    	});
    	$('.ent-detail-bottom span:eq(1)').on('click', function(){
    		var content = {
    			'id': id,
    			'type': 2,
    			'audit_msg': $('.shenhe textarea').val()
    		};
    		
    		$.ajax({
    			type: "post",
    			url: api+"/api/ent_cert?access_token="+access_token+"&user_id="+user_id,
    			async: true,
    			data: JSON.stringify(content),
    			dataType: 'json'
    		}).then(function(certmsg){
    			if(certmsg.err_code == 0){
    				layer.alert('驳回成功', {'title': false,'closeBtn': 0}, function(){
    					window.location.href = 'back-ent.html';
    				});
    			}else{
    				layer.alert(certmsg.msg, {'title': false,'closeBtn': 0});
    			}
    		});
    	});
    	
    	//点击ent_pic元素隐藏
    	$('#ent-pic').on('click', function(){
    		$(this).hide();
    	});
    	//点击图片显示大图
    	$('#ent-detail').on('click', 'img', function(){
    		$('#ent-pic').show();
    	});
    	
    	//从浏览器的地址栏获取传参
		function GetQueryString(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});