/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery','cookie'],function($,cookie){
       
    	/**
    	 * 公用效果
    	 */
    	//分类选择模拟
       	$(".select_box").click(function(event){   
            event.stopPropagation();
            $(this).find(".option").toggle();
            $(this).parent().siblings().find(".option").hide();
        });
        $(document).click(function(event){
            var eo=$(event.target);
            if($(".select_box").is(":visible") && eo.attr("class")!="option" && !eo.parent(".option").length)
            $('.option').hide();                                      
        });
        /*赋值给文本框*/
        $(".option a").click(function(){
            var value=$(this).text();
            $(this).parent().siblings(".select_txt").text(value);
            $("#select_value").val(value)
        });
		
        //点击退出按钮
        $('.user-top .user-info div').on('click', function(){
        	$.cookie("user_name", '', { expires: -1, path:'/', domain: "bancai.com"});
        	$.cookie("access_token", '', { expires: -1, path:'/', domain: "bancai.com"});
        	$.cookie("user_id", '', { expires: -1, path:'/', domain: "bancai.com"});
        	window.location.href = 'http://www.bancai.com/login_seller.html?usertype=1';
        });
        
        //登录成功后用户名显示
        $('.header-top-box div h2:eq(1) a').html($.cookie('user_name_pt'));
    });
});