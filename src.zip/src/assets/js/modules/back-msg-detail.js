require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	var msg_id = GetQueryString('msg_id');
		//获取消息列表
    	$.ajax({
    		type: "get",
    		url: api+"/api/message?access_token="+access_token+"&user_id="+user_id+"&msg_id="+msg_id,
    		async: true,
    		dataType: 'json'
    	}).then(function(msgdetail){
    		if(msgdetail.err_code != 0){
    			layer.alert(msgdetail.msg, {'title': false,'closeBtn': 0});
    			return false;
    		}
    		$('.buyer-right-bottom h3').html(msgdetail.data.title);
    		$('.msgzhu span:eq(0)').html(msgdetail.data.pub_user);
    		$('.msgzhu span:eq(1)').html(msgdetail.data.pub_time);
    		if(msgdetail.data.range == 0){    			
    			$('.msgzhu span:eq(2) em').html('所有用户');
    		}else if(msgdetail.data.range == 2){
    			$('.msgzhu span:eq(2) em').html('卖家');
    		}else{
    			$('.msgzhu span:eq(2) em').html('买家');
    		}
    		$('.msgcontent').html(msgdetail.data.content);
    	});
    	/**
    	 * 交互效果
    	 */
    	
    	//从浏览器的地址栏获取传参
		function GetQueryString(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(5).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});