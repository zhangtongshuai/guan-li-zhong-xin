require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	
    	var shop_id = GetQueryString('shop_id');
    	
    	$.ajax({
    		type: "get",
    		url: api+"/api/shop?access_token="+access_token+"&user_id="+user_id+"&shop_id="+shop_id,
    		async: true,
    		dataType: 'json'
    	}).then(function(shopmsg){
    		//console.log(shopmsg);
    		if(shopmsg.err_code == 0){
    			var shop_base = template('shop-base-tem', shopmsg.data);
    			$('.shop-base').html(shop_base);
    			
    			//企业简介
    			$('.shop-desc p').html(shopmsg.data.profile);
    			
    			//图片上传
				$('#pt-logo').on('change', function(event) {
					//获取图片的大小
					var fileSize = this.files[0].size;
					//对于图片的大小进行比较
					if(fileSize > 2 * 1024 * 1024) {
						layer.alert("上传图片大小不能超过2M", {'title': false,'closeBtn': 0});
						return false;
					} else {
						var file = $(this)[0].files[0];
						if(!/image\/\w+/.test(file.type)){   
							alert("请确保文件为图像类型"); 
							return false; 
						}
						r = new FileReader();  //本地预览
						r.onload = function(){
							var pictureFile = r.result;
							//没有上传完之前input隐藏
							$(this).hide();
							
							var product_commit_obj = {
								user_id: user_id,
								access_token: access_token,
								simage: pictureFile
							};
							$.ajax({
								type: "post",
								url: api+"/api/Upload_Image",
								async:true,
								data: JSON.stringify(product_commit_obj),
								dataType: 'json'
							}).then(function(picUploadData){
								//console.log(picUploadData)
								if(picUploadData.err_code == 0){
									$('.shop-base dd:eq(5) em img').attr({'src': picUploadData.data.image_url}).show();
									$('.shop-base dd:eq(6)').hide();
									$('.shop-base dd:eq(7)').show();
								}else{
									layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});	
								}
							});
						}
						r.readAsDataURL(file);    //Base64
						
//						var imageUrl = getObjectURL($(this)[0].files[0]);
//						var index = $(this)[0].files[0].name.lastIndexOf('.');
//						var imagethis = $(this)[0].files[0].name.slice(index+1);
//						if(imagethis == 'jpg'){
//							imagethis = 'jpeg';
//						}
//						convertImgToBase64(imageUrl, function(base64Img) {
//							pictureFile = base64Img;
//							//没有上传完之前input隐藏
//							$(this).hide();
//							
//							var product_commit_obj = {
//								user_id: user_id,
//								access_token: access_token,
//								simage: pictureFile
//							};
//							$.ajax({
//								type: "post",
//								url: api+"/api/Upload_Image",
//								async:true,
//								data: JSON.stringify(product_commit_obj),
//								dataType: 'json'
//							}).then(function(picUploadData){
//								//console.log(picUploadData)
//								if(picUploadData.err_code == 0){
//									$('.shop-base dd:eq(5) em img').attr({'src': picUploadData.data.image_url}).show();
//									$('.shop-base dd:eq(6)').hide();
//									$('.shop-base dd:eq(7)').show();
//								}else{
//									layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});	
//								}
//							});
//						}, 'image/'+imagethis);
//						
//						event.preventDefault();
					}
				});
				//保存按钮
				$('.shop-base b.layui-btn.layui-btn-warm:eq(1)').on('click', function(){
    				var pt_logo = $('.shop-base dd:eq(5) img').attr('src');
    				var content = {
    					'shop_id': shopmsg.data.shop_id,
    					'pt_logo': pt_logo
    				};
    				$.ajax({
    					type: "post",
    					url: api+"/api/shop?access_token="+access_token+"&user_id="+user_id,
    					async: true,
    					data: JSON.stringify(content),
    					dataType: 'json'
    				}).then(function(savemsg){
    					//console.log(savemsg);
    					if(savemsg.err_code == 0){
    						$('.shop-base dd:eq(6)').show();
    						$('.shop-base dd:eq(7)').hide();
    					}else{
    						layer.alert(savemsg.msg, {'title': false,'closeBtn': 0});
    					}
    				});
    			});
    			
    			//店铺横幅
    			//图片容器的宽度
    			var banner_len = shopmsg.data.banner.length;
    			var banner_img = template('img-zhan-tem', shopmsg.data.banner);
    			$('.shop-banner:eq(0) .img-zhan').html(banner_img);
    			
    			$('.shop-banner:eq(0) .img-zhan div').css({'width': 100*banner_len+'%'});
    			$('.shop-banner:eq(0) .img-zhan div img').css({'width': (100/banner_len - 0.1)+'%'});
    			//点击左右按钮
    			var click_nub = 0;//记录点击的次数
    			$('.shop-banner:eq(0) .img-zhan p:eq(1)').on('click', function(){
    				-- click_nub;
    				if(-click_nub > banner_len - 1){
    					click_nub = -(banner_len - 1);
    				}
    				$('.shop-banner:eq(0) .img-zhan div').animate({'margin-left': click_nub*100+'%'});
    			});
    			$('.shop-banner:eq(0) .img-zhan p:eq(0)').on('click', function(){
    				++ click_nub;
    				if(click_nub > 0){
    					click_nub = 0;
    				}
    				$('.shop-banner:eq(0) .img-zhan div').animate({'margin-left': click_nub*100+'%'});
    			});
    			
    			
    			//企业资质和展示
    			//资质
    			var certification_len = shopmsg.data.certification.length;
    			var certification_img = template('img-zhan-zi-tem', shopmsg.data.certification);
    			$('.shop-banner:eq(1) .img-zhan').html(certification_img);
    			//展示
    			var display_len = shopmsg.data.display.length;
    			var display_img = template('img-zhan-zi-tem', shopmsg.data.display);
    			$('.shop-banner:eq(2) .img-zhan').html(display_img);
    			//资质图片容器的宽度
    			$('.shop-banner:eq(1) .img-zhan div').css({'width': 250*certification_len+'px'});
    			//展示图片容器的宽度
    			$('.shop-banner:eq(2) .img-zhan div').css({'width': 250*display_len+'px'});
    			
    			//图片加载完成后看宽高比
    			var img_list = $('.shop-banner .img-zhan div span img');
    			$.each(img_list, function(i, v) {
    				var wg = v.width/v.height;
    				if(wg > 1){
    					$(v).css({'width': '240px'});
    				}else{
    					$(v).css({'height': '192px'});
    				}
    			});
    			$('.shop-banner .img-zhan div img').on('click', function(){
    				$('#big-img img').attr({'src': $(this).attr('src')});
    				$('#big-img').show();
    			});
    			$('#big-img').on('click', function(){
    				$(this).hide();
    			});
    			
    			//资质点击左右按钮
    			var click_nub_zi = 0;//记录点击的次数
    			$('.shop-banner:eq(1) .img-zhan p:eq(1)').on('click', function(){
    				-- click_nub_zi;
    				if(-click_nub_zi > certification_len - 4){
    					click_nub_zi = -(certification_len - 4);
    				}
    				$('.shop-banner:eq(1) .img-zhan div').animate({'margin-left': click_nub_zi*250+'px'});
    			});
    			$('.shop-banner:eq(1) .img-zhan p:eq(0)').on('click', function(){
    				++ click_nub_zi;
    				if(click_nub_zi > 0){
    					click_nub_zi = 0;
    				}
    				$('.shop-banner:eq(1) .img-zhan div').animate({'margin-left': click_nub_zi*250+'px'});
    			});
    			
    			//展示点击左右按钮
    			var click_nub_zhan = 0;//记录点击的次数
    			$('.shop-banner:eq(2) .img-zhan p:eq(1)').on('click', function(){
    				-- click_nub_zhan;
    				if(-click_nub_zhan > display_len - 4){
    					click_nub_zhan = -(display_len - 4);
    				}
    				$('.shop-banner:eq(2) .img-zhan div').animate({'margin-left': click_nub_zhan*250+'px'});
    			});
    			$('.shop-banner:eq(2) .img-zhan p:eq(0)').on('click', function(){
    				++ click_nub_zhan;
    				if(click_nub_zhan > 0){
    					click_nub_zhan = 0;
    				}
    				$('.shop-banner:eq(2) .img-zhan div').animate({'margin-left': click_nub_zhan*250+'px'});
    			});
    			
    			
    			//判断店铺状态
    			if(shopmsg.data.status == 0){
    				$('.bei-zhu .layui-btn-primary').off('click').addClass('layui-btn-disabled');
    			}else{
    				$('.bei-zhu .layui-btn-danger').off('click').addClass('layui-btn-disabled').css({'background-color': '#eee'});
    			}
    		}else{
    			layer.alert(shopmsg.msg, {'title': false,'closeBtn': 0});
    		}
    	});
    	/**
    	 * 交互效果
    	 */
    	//点击上线下线按钮
		$('.bei-zhu .layui-btn-danger').on('click', function(){
			var content = {
				'shop_id': shop_id,
				'status': '1',
				'msg': $('.bei-zhu textarea').val()
			};
			$.ajax({
				type: "put",
				url: api+"/api/shop?access_token="+access_token+"&user_id="+user_id,
				async: true,
				data: JSON.stringify(content),
				dataType: 'json'
			}).then(function(xianmsg){
				if(xianmsg.err_code == 0){
					layer.alert('上线成功', {'title': false,'closeBtn': 0}, function(){
						window.location.href = 'back-shop.html';
					});
				}else{
					layer.alert(xianmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		});
		$('.bei-zhu .layui-btn-primary').on('click', function(){
			var content = {
				'shop_id': shop_id,
				'status': '0',
				'msg': $('.bei-zhu textarea').val()
			};
			$.ajax({
				type: "put",
				url: api+"/api/shop?access_token="+access_token+"&user_id="+user_id,
				async: true,
				data: JSON.stringify(content),
				dataType: 'json'
			}).then(function(xianmsg){
				if(xianmsg.err_code == 0){
					layer.alert('下线成功', {'title': false,'closeBtn': 0}, function(){
						window.location.href = 'back-shop.html';
					});
				}else{
					layer.alert(xianmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		});
		
		//上传图片的方法
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 1;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}
		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		}
    	
    	//从浏览器的地址栏获取传参
		function GetQueryString(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});