require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//上传编辑器实例化
		var ue = UE.getEditor('editor',{maximumWords: 5000});
    	/**
    	 * 交互效果
    	 */
    	$('.buyer-right-bottom .layui-btn').on('click', function(){
    		//产品详情的信息
			var arrEditor = [],
				message;//产品详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        message = arrEditor.join("\n");
    		
    		var content = {
    			'title': $('#zxtitle').val(),
    			'content': message,
    			'msg_type': $('.zxkeyword:eq(0) input[name=xiaoxi]:checked').val(),
    			'range': $('.zxkeyword:eq(1) input[name=fanwei]:checked').val()
    		};
    		
    		if(content.title == ''){
    			layer.alert('标题没有填写', {'title': false,'closeBtn': 0});
    		}else if(content.title.indexOf(' ') >= 0){
    			layer.alert('标题中不能有空格', {'title': false,'closeBtn': 0});
    		}else if(content.content.trim() == ''){
    			layer.alert('内容没有填写', {'title': false,'closeBtn': 0});
    		}else{
    			$.ajax({
    				type: "post",
    				url: api+"/api/message?access_token="+access_token+"&user_id="+user_id,
    				async: true,
    				data: JSON.stringify(content),
    				dataType: 'json'
    			}).then(function(fbmsg){
    				//console.log(fbmsg);
    				if(fbmsg.err_code == 0){
    					layer.alert('发布成功', {'title': false,'closeBtn': 0}, function(){
    						window.location.href = 'back-msgs.html';
    					});
    				}else{
    					layer.alert(fbmsg.msg, {'title': false,'closeBtn': 0});
    				}
    			});
    		}
    	});
    	
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(5).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});