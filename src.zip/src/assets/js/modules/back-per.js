require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	// 筛选方法//init
	    $(function () {
	        searchFilter(1)
	    });
	    
		function searchFilter(pageindex){
			var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
	        }
            
			$.ajax({
				url: api+"/api/per_cert_list?access_token="+access_token+"&user_id="+user_id+"&page_no="+pageNo,
				type: 'get',
				dataType: 'json',
				success:function(result){
					//console.log(result);
					if (result.err_code != 0) {
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
						return false;
					}
					var count = parseInt(result.data.record_total);
                    var totalPage = parseInt(result.data.page_total);
                    if (count == 0) {
                    	$('table').after('<p>没有数据</p>');
                    }else{
	                    var data = result.data.list;
	                    var html = template('entlist', data);
						$('table tbody').html(html);
						//生成分页
						kkpager.generPageHtml({
							pno: pageNo,
							//总页码
							total : totalPage,
							//总数据条数
							totalRecords : count,
							mode : 'click',
							click : function(n){
							    this.selectPage(pageNo);
			                    searchPage(n);
			                    return false;
							}
						},true);
                   }
				},
				error: function () {
                    layer.msg('网络请求失败，请刷新后重试！');
                }	
			})
		}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
    	/**
    	 * 交互效果
    	 */
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});