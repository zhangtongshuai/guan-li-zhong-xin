require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
        // var  access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734',
    	 //      user_id = 100000;
        /**
         * 交互效果
         */
        //选项卡效果
        $(".product_detail_content ol li").click(function(){
            var index=$(".product_detail_content ol li").index(this)
            $(this).addClass("now").siblings().removeClass("now")
            $("#product_detail_content_info .product_detail_list").eq(index).addClass("current").siblings().removeClass("current")
        })

        function getUrlParam(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); // 构造一个含有目标参数的正则表达式对象
            var r = window.location.search.substr(1).match(reg); // 匹配目标参数
            if (r != null)
                return decodeURIComponent(r[2]);
            return null; // 返回参数值
        }
        var catagory = getUrlParam("catagory");
        var sku_id = getUrlParam("sku_id");
        //console.log(catagory)
        //console.log(sku_id)
        $.ajax({
            url: api+"/api/product_detail?access_token="+access_token+"&user_id="+user_id+"&catagory="+catagory+"&sku_id="+sku_id,
            type: 'get',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success:function(r){
                //console.log(r.data);
                if(r.err_code == 0){
                    $("#user_name").html(r.data.user_name);
                    $("#phone_no").html(r.data.phone_no);
                    $("#sub_time").html(r.data.sub_time);
                    var data=r.data;
                    var html=template('tpl_product_detail_content_order',data);
                    document.getElementById('product_detail_content_order').innerHTML=html;
                }else{
                    layer.alert(r.msg)
                }
            },
            error: function(){
                layer.msg('网络请求失败，请刷新后重试！');
            }
        })

        $(".adopt_btn").click(function () {
            var insertData = {
                "id" : sku_id,
                "type": 1,
                "audit_msg" : $("#audit_msg").val(),
            };
            //console.log(JSON.stringify(insertData));
            //发送数据到后台
            $.ajax({
                type:"POST",
                async:true,
                data: JSON.stringify(insertData),
                dataType: "json",
                url:api+'/api/product_detail?access_token='+ access_token +'&user_id='+ user_id,
                contentType: "application/json; charset=utf-8",
                success:function(msg){
                   // console.log(msg);
                    if(msg.err_code == 0){
                        //layer.alert('通过审核');
                        window.location.href="http://pt.bancai.com/back-product.html";
                    }else{
                        layer.alert(msg.msg);
                    }
                },
                error:function(){
                    layer.msg('网络请求失败，请刷新后重试！');
                }
            });
        });

        $(".reject_btn").click(function () {
            if($("#audit_msg").val()==''){
                layer.alert("审核意见没有填写");
                return false;
            }
            var insertData = {
                "id" : sku_id,
                "type": 2,
                "audit_msg" : $("#audit_msg").val(),
            };
            //console.log(JSON.stringify(insertData));
            //发送数据到后台
            $.ajax({
                type:"POST",
                async:true,
                data: JSON.stringify(insertData),
                dataType: "json",
                url:api+'/api/product_detail?access_token='+ access_token +'&user_id='+ user_id,
                contentType: "application/json; charset=utf-8",
                success:function(re){
                    //console.log(msg);
                    if(re.err_code == 0){
                        //layer.alert('审核产品被驳回');
                        window.location.href="http://pt.bancai.com/back-product.html";
                    }else{
                        layer.alert(re.msg);
                    }
                },
                error:function(){
                    layer.msg('网络请求失败，请刷新后重试！');
                }
            });
        });
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(1).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});