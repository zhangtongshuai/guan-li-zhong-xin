require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//默认显示
    	msglist('0');
    	
		//获取消息列表
		$('.msgstop span').on('click', function(){
	    	var news_type = $(this).find('em').data().msgtype;
	    	$('.msgstop span').find('em').removeClass('choose');
	    	$(this).find('em').addClass('choose');
	    	msglist(news_type);
	    });
		
    	//消息数量
    	function msglist(msg_id){
    		//init
		    $(function () {
		        searchFilter(1);
		    });
		    
			function searchFilter(pageindex){
				var pageNo = getParameter('pageIndex');
	            if (!pageNo) {
	                pageNo = pageindex;
		        }
	            
				$.ajax({
					url: api+"/api/news?access_token="+access_token+"&user_id="+user_id+"&news_type="+msg_id+"&page_no="+pageNo,
					type: 'get',
					dataType: 'json',
					success:function(result){
						//console.log(result);
						if (result.err_code != 0) {
							layer.alert(result.msg, {'title': false,'closeBtn': 0});
							return false;
						}
						var count = parseInt(result.data.record_total);
	                    var totalPage = parseInt(result.data.page_total);
	                    if (count == 0) {
	                    	$('#msglist-back').hide();
	                    	$('#no-data').show();
	                    	$('#kkpager').hide();
	                    }else{
	                    	$('#msglist-back').show();
	                    	$('#no-data').hide();
	                    	$('#kkpager').show();
	                    	
	                    	$('#msglist-back').html('');
		                    var data = result.data.list;
		                    var html = template('msglisttem', data);
							$('#msglist-back').html(html);
							//生成分页
							kkpager.generPageHtml({
								pno: pageNo,
								//总页码
								total : totalPage,
								//总数据条数
								totalRecords : count,
								mode : 'click',
								click : function(n){
								    this.selectPage(pageNo);
				                    searchPage(n);
				                    return false;
								}
							},true);
	                   }
					},
					error: function () {
	                    layer.msg('网络请求失败，请刷新后重试！');
	                }	
				})
			}
			//ajax翻页
		    function searchPage(n) {
		        searchFilter(n);
		    }
			//分页数量
			function getParameter(name) { 
				var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
				var r = window.location.search.substr(1).match(reg); 
				if (r!=null) return unescape(r[2]); return null;
			}
    	}
    	/**
    	 * 交互效果
    	 */
    	$('#msglist-back').on('click', 'i', function(){
    		var news_id = $(this).parents('ul').data().msgid;
    		layer.confirm('您真的要删除此资讯吗？', {'title': false,'closeBtn': 0}, function(i){
				$.ajax({
	    			type: "delete",
	    			url: api+"/api/news?access_token="+access_token+"&user_id="+user_id+"&news_id="+news_id,
	    			async: true,
	    			dataType: 'json'
	    		}).then(function(delmsg){
	    			//console.log(delmsg);
	    			if(delmsg.err_code == 0){
	    				$.each($('.msgstop span'), function(v,i){
    						if($(this).children('em').hasClass('choose')){
    							var news_type = $(this).children('em').data().msgtype;
    							msglist(news_type);
    						}
    					});
	    				layer.alert('删除成功', {'title': false,'closeBtn': 0});
	    			}else{
	    				layer.alert(delmsg.msg, {'title': false,'closeBtn': 0});
	    			}
	    		});
				//关闭弹框
				layer.close(i);
			});
    	});
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(3).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});