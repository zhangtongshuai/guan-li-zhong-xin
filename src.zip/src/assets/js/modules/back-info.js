require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	//上传编辑器实例化
		var ue = UE.getEditor('editor',{maximumWords: 5000});
		//头条的上传照片
		var toutiaoimg = '';
    	/**
    	 * 交互效果
    	 */
    	//头条封面显示隐藏
    	$('.zxkeyword:eq(0) .layui-unselect.layui-form-checkbox').on('click', function(){
    		var toutiao = $(this).attr('class');
    		if(toutiao.indexOf('layui-form-checked') >= 0){
    			$('.zxkeyword:eq(1)').show();
    		}else{
    			$('.zxkeyword:eq(1)').hide();
    		}
    	});
    	
    	//发布
    	$('.buyer-right-bottom .layui-btn:eq(1)').on('click', function(){
    		//产品详情的信息
			var arrEditor = [],
				message;//产品详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        message = arrEditor.join("\n");
    		
    		var tou_tiao = $('.zxkeyword:eq(0) .layui-unselect.layui-form-checkbox').attr('class');
    		var is_tou_tiao,
    			news_type;
    		if(tou_tiao.indexOf('layui-form-checked') >= 0){
    			is_tou_tiao = '1';
    			news_type = '0';
    		}else{
    			is_tou_tiao = '0';
    			news_type = $('.zxkeyword.zxlx input[name=zxlx]:checked').val()
    		}
    		
    		var content = {
    			'title': $('#zxtitle').val(),
    			'content': message,
    			'keywords': changeDouHao($('#zxkeyword').val()),
    			'is_tou_tiao': is_tou_tiao,
    			'news_type': news_type,
    			'tou_tiao_img': toutiaoimg
    		};
    		
    		if(content.title == ''){
    			layer.alert('标题没有填写', {'title': false,'closeBtn': 0});
    		}else if(content.title.indexOf(' ') >= 0){
    			layer.alert('标题中不能有空格', {'title': false,'closeBtn': 0});
    		}else if(content.keywords == ''){
    			layer.alert('关键词没有填写', {'title': false,'closeBtn': 0});
    		}else if(content.keywords.indexOf(' ') >= 0){
    			layer.alert('关键词中不能有空格', {'title': false,'closeBtn': 0});
    		}else if(is_tou_tiao == '1' && content.tou_tiao_img == ''){
    			layer.alert('头条封面没有上传', {'title': false,'closeBtn': 0});
    		}else if(content.content.trim() == ''){
    			layer.alert('内容没有填写', {'title': false,'closeBtn': 0});
    		}else{
    			$.ajax({
    				type: "post",
    				url: api+"/api/news?access_token="+access_token+"&user_id="+user_id,
    				async: true,
    				data: JSON.stringify(content),
    				dataType: 'json'
    			}).then(function(fbmsg){
    				//console.log(fbmsg);
    				if(fbmsg.err_code == 0){
    					layer.alert('发布成功', {'title': false,'closeBtn': 0}, function(){
    						window.location.href = 'back-infos.html';
    					});
    				}else{
    					layer.alert(fbmsg.msg, {'title': false,'closeBtn': 0});
    				}
    			});
    		}
    	});
		
		//图片上传
		$('#face').on('change', function(event) {
			//获取图片的大小
			var fileSize = this.files[0].size;
			//对于图片的大小进行比较
			if(fileSize > 2 * 1024 * 1024) {
				layer.alert("上传图片大小不能超过2M", {'title': false,'closeBtn': 0});
				return false;
			} else {
				var file = $(this)[0].files[0];
				if(!/image\/\w+/.test(file.type)){   
					alert("请确保文件为图像类型"); 
					return false; 
				}
				r = new FileReader();  //本地预览
				r.onload = function(){
					var pictureFile = r.result;
					//没有上传完之前input隐藏
					$(this).hide();
					
					var product_commit_obj = {
						user_id: user_id,
						access_token: access_token,
						simage: pictureFile
					};
					$.ajax({
						type: "post",
						url: api+"/api/Upload_Image",
						async:true,
						data: JSON.stringify(product_commit_obj),
						dataType: 'json'
					}).then(function(picUploadData){
						//console.log(picUploadData)
						if(picUploadData.err_code == 0){
							$('#face').show();
							$('.zxkeyword.zxface em').show();
							toutiaoimg = picUploadData.data.image_url;
						}else{
							layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});	
						}
					});
				}
				r.readAsDataURL(file);    //Base64
				
//				var imageUrl = getObjectURL($(this)[0].files[0]);
//				var index = $(this)[0].files[0].name.lastIndexOf('.');
//				var imagethis = $(this)[0].files[0].name.slice(index+1);
//				if(imagethis == 'jpg'){
//					imagethis = 'jpeg';
//				}
//				convertImgToBase64(imageUrl, function(base64Img) {
//					pictureFile = base64Img;
//					//没有上传完之前input隐藏
//					$(this).hide();
//					
//					var product_commit_obj = {
//						user_id: user_id,
//						access_token: access_token,
//						simage: pictureFile
//					};
//					$.ajax({
//						type: "post",
//						url: api+"/api/Upload_Image",
//						async:true,
//						data: JSON.stringify(product_commit_obj),
//						dataType: 'json'
//					}).then(function(picUploadData){
//						//console.log(picUploadData)
//						if(picUploadData.err_code == 0){
//							$('#face').show();
//							$('.zxkeyword.zxface em').show();
//							toutiaoimg = picUploadData.data.image_url;
//						}else{
//							layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});	
//						}
//					});
//				}, 'image/'+imagethis);
//				
//				event.preventDefault();
			}
		});
		
		//上传图片的方法
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 1;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}
		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		}
		
        //将中文逗号转换成英文逗号
		function changeDouHao(str){
			str=str.replace(/，/ig,',');
			return str;
		}
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(3).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});