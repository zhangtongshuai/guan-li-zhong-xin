require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
		$("#slider1").slider({
    		width: 330, // width
			height: 46, // height
			callback: function(result) {
				if(result){
					$('.back-login li button').css({'background-color': '#ff3c00'});
					$('.back-login li button').on('click', function(){
						var logincontent = {
							'username': $('#back-admin').val(),
							'password': $('#back-pwd').val()
						};
						
						if(logincontent.username == ''){
							layer.alert('用户名没有填写', {'title': false,'closeBtn': 0});
						}else if(logincontent.username.indexOf(' ') >= 0){
							layer.alert('用户名不允许有空格', {'title': false,'closeBtn': 0});
						}else if(logincontent.password == ''){
							layer.alert('密码没有填写', {'title': false,'closeBtn': 0});
						}else if(logincontent.password.indexOf(' ') >= 0){
							layer.alert('密码不允许有空格', {'title': false,'closeBtn': 0});
						}else{
							logincontent.password = md5(logincontent.password);
							$.ajax({
								type: "post",
								url: api+"/api/login",
								async: true,
								data: JSON.stringify(logincontent),
								dataType: 'json'
							}).then(function(loginmsg){
								//console.log(loginmsg);
								if(loginmsg.err_code == 0){
									$.cookie("user_name", '', { expires: -1, path:'/', domain: "bancai.com"});
						        	$.cookie("access_token", '', { expires: -1, path:'/', domain: "bancai.com"});
						        	$.cookie("user_id", '', { expires: -1, path:'/', domain: "bancai.com"});
						        	$.cookie("seller", '', { expires: -1, path:'/', domain: "bancai.com"});
						        	$.cookie("user_type", '', { expires: -1, path:'/', domain: "bancai.com"});
									$.cookie('access_token_pt', loginmsg.data.access_token);
									$.cookie('user_id_pt', loginmsg.data.user_id);
									$.cookie('user_name_pt', loginmsg.data.user_name);
									$.cookie('role', loginmsg.data.role);
									$.cookie('user_type', '2');
									window.location.href = 'http://pt.bancai.com';
								}else{
									layer.alert(loginmsg.msg, {'title': false,'closeBtn': 0});
								}
							});
						}
					});
				}
			}
		});
    	/**
    	 * 交互效果
    	 */
		$('#back-admin,#back-pwd').on('input', function(){
			var thisval = $(this).val();
			if(thisval == ''){
				$(this).parent().next().hide();
			}else{
				$(this).parent().next().show();
			}
		});
		
		$('.back-login li i.smallcha').on('click', function(){
			$(this).hide().prev().find('input').focus().val('');
		});
    });
});