require(['../common/common'],function(c){
    require(['jquery','template','md5','slider','layui','cookie','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var access_token = $.cookie('access_token_pt'),
    		user_id = $.cookie('user_id_pt');
//  	access_token = '8e27eb39-8c8d-44f5-82bd-878ab8c6c734';
//  	user_id = 100000;
    	
    	var shop_name = '',
    		extension = '',
    		status = '';
    	
		var that;//承接一下点击的当前对象
		var content = {
			'shop_id': '',
			'extension': ''
		};//网络请求上传数据
    	//默认
    	shopSearch(shop_name,extension,status);
    	
    	$('.shop-search span:eq(3)').on('click', function(){
    		shop_name = $('#shop-name').val();
    		status = $('.layui-form:eq(0) option:selected').val();
    		extension = $('#fen-ji-nub').val();
    		shopSearch(shop_name,extension,status);
    	});
    	
    	function shopSearch(shop_name,extension,status){
    		//init
		    $(function () {
		        searchFilter(1)
		    });
		    
			function searchFilter(pageindex){
				var pageNo = getParameter('pageIndex');
	            if (!pageNo) {
	                pageNo = pageindex;
		        }
	            
				$.ajax({
					url: api+"/api/shop_400?access_token="+access_token+"&user_id="+user_id+"&shop_name="+shop_name+"&extension="+extension+"&status="+status+"&page_no="+pageNo,
					type: 'get',
					dataType: 'json',
					success:function(result){
						//console.log(result);
						if (result.err_code != 0) {
							layer.alert(result.msg, {'title': false, 'closeBtn': 0});
							return false;
						}
						var count = parseInt(result.data.record_total);
	                    var totalPage = parseInt(result.data.page_total);
	                    if (count == 0) {
	                    	$('table tbody').html('');
	                    	$('table').next('p').remove();
	                    	$('#kkpager').hide();
	                    	$('table').after('<p class="p-no-data">没有数据</p>');
	                    }else{
	                    	$('.p-no-data').hide();
	                    	$('#kkpager').show();
	                    	$('table tbody').html('');
		                    var data = result.data.list;
		                    var html = template('entlist', data);
							$('table tbody').html(html);
							//生成分页
							kkpager.generPageHtml({
								pno: pageNo,
								//总页码
								total : totalPage,
								//总数据条数
								totalRecords : count,
								mode : 'click',
								click : function(n){
								    this.selectPage(pageNo);
				                    searchPage(n);
				                    return false;
								}
							},true);
							
							//获取shop_id
							var shop_id;
							//点击设置按钮
							$('table td p.have-400 b:nth-of-type(3),table td p.handle-color').on('click', function(){
								shop_id = $(this).parents('tr').data().shopid;
								that = this;
								var extension = $(this).parents('tr').data().extension;
								$('.tan-box').show();
								$('#tan-write-400').val(extension);
								content.shop_id = shop_id;
							});
	                    }
					},
					error: function () {
	                    layer.msg('网络请求失败，请刷新后重试！');
	                }	
				})
			}
    	}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
    	/**
    	 * 交互效果
    	 */
    	//点击弹出框的确认按钮
		$('.tan-box dd span:eq(0)').on('click', function(){
			var extension = $('#tan-write-400').val();
			if('' == extension){
				layer.alert('分机号码不能为空', {'title': false,'closeBtn': 0});
			}else if(!/^\d{4,6}$/.test(extension)){
				layer.alert('分机号码格式不正确', {'title': false,'closeBtn': 0});
			}else{
				content.extension = extension;
				$.ajax({
					type: "post",
					url: api+"/api/shop_400?access_token="+access_token+"&user_id="+user_id,
					async: true,
					data: JSON.stringify(content),
					dataType: 'json'
				}).then(function(zhimsg){
					//console.log(zhimsg);
					if(zhimsg.err_code == 0){
						$(that).parents('tr').find('p.have-400').removeClass('none-she-zhi');
						$(that).parents('tr').find('p.handle-color').addClass('none-she-zhi');
						$(that).parents('tr').find('p.have-400 b:eq(0)').html(extension);
						$('.tan-box').hide();
					}else{
						layer.alert(zhimsg.msg, {'title': false,'closeBtn': 0});
					}
				});
			}
		});
    	
    	//点击设置弹窗的叉号
    	$('.tan-box i,.tan-box dd span:eq(1)').on('click', function(){
    		$('.tan-box').hide();
    	});
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
    });
});