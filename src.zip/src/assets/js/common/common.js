requirejs.config({
    paths:{
        'template':'../lib/template',
        'jquery':'../lib/jquery.min',
        'base':'../modules/base',
        'fb':'../modules/seller-fb-com',
        'jquery.lazyload':'../lib/jquery.lazyload.min',
        'slider':'../lib/jquery.slider.min',
        'jquery.validate':'../lib/jquery.validate.min',
        'md5':'../lib/md5.min',
        'global':'../modules/global',
        'pager':'../modules/pager_default',
        'layui':'../lib/layui.all',
        'layu':'../lib/layui',
        'cookie':'../lib/jquery.cookie',
        'jiathis':'http://v3.jiathis.com/code/jia.js?ie=utf-8',
        'area':'../lib/area'
    },
    shim: {
        "slider": {
            deps: ['jquery']
        }
    }
});

//ajax中url的参数
//var api = 'http://192.168.100.90/ptapi';
//var capapi = 'http://192.168.100.90/cache-api';

var api = 'http://ptapi.bancai.com';
var capapi = 'http://capi.bancai.com'